import '/js/components/etiquetaPizza.js';
import { PizzaService } from "/js/services/pizzaService.js";

document.addEventListener('DOMContentLoaded', async () => {
    try {
        const pizzes = await PizzaService.getAllPizzes();
        const lista = document.getElementById('contenedor');

        pizzes.forEach(p => {
            const pizzaElement = document.createElement('pizza-card');

            const nombre = p.nombre || 'Pizza desc';
            const descripcion = p.descripcion || 'Descripción desconocida';
            const precio = p.precio || 'Precio desconocido';
            const es_vegetariana = p.es_vegetariana ? 'VEGETARIANA' : '';
            const img = p.img || '';
            
            // Verificación de alérgenos
            const alergens = Array.isArray(p.alergens) && p.alergens.length > 0 ? p.alergens : ['no_alergenos'];
            pizzaElement.setAttribute('pizza-alergens', alergens.join(','));

            pizzaElement.setAttribute('pizza-id', p.id);
            pizzaElement.setAttribute('pizza-desc', descripcion);
            pizzaElement.setAttribute('pizza-nom', nombre);
            pizzaElement.setAttribute('pizza-vegetariana', es_vegetariana);
            pizzaElement.setAttribute('pizza-preu', precio);
            pizzaElement.setAttribute('pizza-img', img);

            lista.appendChild(pizzaElement);
        });
    } catch (error) {
        console.error("Error cargando las pizzas", error);
    }
});
